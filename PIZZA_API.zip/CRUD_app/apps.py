from django.apps import AppConfig


class CrudAppConfig(AppConfig):
    name = 'CRUD_app'
