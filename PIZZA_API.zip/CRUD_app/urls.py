


from django.contrib import admin
from django.urls import path , include
from .import views
urlpatterns = [
    
    path("" , views.ReadCreate.as_view() , name='dashboard'),
    path("<int:pk>" , views.crud_class.as_view() , name='api_view'),
]
