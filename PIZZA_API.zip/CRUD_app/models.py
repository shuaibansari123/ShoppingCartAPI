from django.db import models



# Create your models here.
class ShoppingCart(models.Model):
    product_name = models.CharField(max_length=122)
    product_disc = models.CharField(max_length=500)
    category= (('Clothes' , 'Clothes') ,('Watches' , 'Watches'), ('Fashion' , 'Fashion') ,('Gifts' , 'Gifts' ) , ('Others' , 'Others'))
    product_category  =  models.CharField(max_length=122 , choices=category , default="Others")
    product_price = models.IntegerField()
    created_time = models.DateTimeField(auto_now_add=True)


    def __str__(self):

        return self.product_name
