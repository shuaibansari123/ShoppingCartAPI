import json
from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from requests.api import request
from rest_framework.parsers import JSONParser
import io
from rest_framework.renderers import JSONRenderer
from django.views.decorators.csrf import csrf_exempt
from .serializer import Pizza_Model_Serializer
from .models import ShoppingCart


from rest_framework.generics import ListCreateAPIView , RetrieveUpdateDestroyAPIView

class ReadCreate(ListCreateAPIView):
    queryset = ShoppingCart.objects.all()
    serializer_class = Pizza_Model_Serializer


class crud_class(RetrieveUpdateDestroyAPIView):
    queryset = ShoppingCart.objects.all()
    serializer_class = Pizza_Model_Serializer




'''
# Create your views here.
def dashboard(request):
    all_obj = Pizza_Model.objects.all()
    return render(request , 'dasboard.html' , {'all_obj' : all_obj , })


def api_view(request):
    if request.method =='GET':
        all_obj = Pizza_Model.objects.all()
        Ser = Pizza_Model_Serializer(all_obj , many=True)
        ser_json = JSONRenderer().render(Ser.data)

        return HttpResponse(ser_json,  content_type='appilcations/json')

'''

    
    