from django.contrib import admin
from .models import ShoppingCart


admin.site.register(ShoppingCart)